select opof.Hora_Operacion, opof.origen, opof.NUMERO_OPERACION, opof.FCH_INGRESO,opof.OPERADOR_COMPRA,
opof.OPERADOR_VENTA, opof.FORMA_OPERATIVA_ID, opof.INSTRUMENTO, opof.FCH_VTO,opof.PLAZO, opof.MONEDA, opof.CANTIDAD,
opof.PRECIO, opof.ESTADO, opof.NRO_OFERTA_COMP,opof.NRO_OFERTA_VEND, opof.AGENTE_COMPRA, opof.AGENTE_VENTA, 
opof.hora_oferta, opof.numero_oferta,opof.tipooferta, opof.OPERADOR, opof.TIPODERECHO, opof.Minuta, opof.pase,
opof.garantia, opof.subyacente,opof.AGENTEOP ,adjo.ID, adjo.COMITENTE, adjo.CUIT, adjo.cantidad_adjudicada 
from(
	(select op.FCH_INGRESO Hora_Operacion,'MC' origen, op.NUMERO numero_OPERACION, op.FCH_INGRESO,op.OPERADOR_COMPRA, 
		op.OPERADOR_VENTA, op.FORMA_OPERATIVA_ID, op.INSTRUMENTO, op.FCH_VTO, op.PLAZO, op.MONEDA, op.CANTIDAD, op.PRECIO, 
		op.ESTADO, op.NRO_OFERTA_COMP, op.NRO_OFERTA_VEND, op.AGENTE_COMPRA, op.AGENTE_VENTA,ofer.FCH_OF_ORIG hora_oferta, 
		ofer.numero numero_oferta,
			case when ofer.tipooferta is null then 
				(select o.TIPOOFERTA 
					from oferta_agente o 
					where ofer.nroofertaoriginal =o.NUMERO and ofer.operador=o.operador 
					and trunc(ofer.fechaingreso) = trunc(o.fechaingreso)
				) else ofer.tipooferta end tipooferta
		,ofer.OPERADOR, ofer.AGENTE AGENTEOP, ofer.TIPODERECHO, 
			case when length(ofer.NUMERO) > 6 then 'M' else null end MINUTA,
				 NULL PASE, NULL GARANTIA
				 ,  case when FORMA_OPERATIVA_ID ='O' then 
				(select i.subyacente 
				from oferta o,instrumento i where o.INSTRUMENTO=i.COD_ALFANUMERICO and o.numero=ofer.nroofertaoriginal 
				   and o.operador=ofer.operador and trunc(o.fechaingreso)=trunc(ofer.fechaingreso)
				) else null end subyacente, op.negociacion_ciega 
		from operacion_agente op, oferta_agente ofer , 
			(select o.NROOFERTAORIGINAL oc,o.operador opc,o.FCH_OF_ORIG fic 
			from oferta o where o.numero = ? and operador = ? and trunc(o.FECHAINGRESO)=?
			)
			originalcompra, 
			(select o.NROOFERTAORIGINAL ov,o.operador opv,o.FCH_OF_ORIG fiv 
			from oferta_agente o where o.numero = ? and operador = ? 
			and trunc(o.FECHAINGRESO)=?) originalventa 
			where (
				(ofer.NROOFERTAORIGINAL = originalcompra.oc and 
				ofer.operador= originalcompra.opc and 
				originalcompra.fic=ofer.FCH_OF_ORIG) 
			or (ofer.NROOFERTAORIGINAL = originalventa.ov and 
				 ofer.operador=originalventa.opv and 
				 originalventa.fiv=ofer.FCH_OF_ORIG)) 
			and op.numero=? 
			and trunc(op.FCH_INGRESO) = ?
			and exists 
				(select * from ordenadjudicacion o 
				where o.NROOFERTA=ofer.numero and o.OPERADOR=ofer.operador and o.FCH_INGRESO = ofer.fechaingreso  
				and o.tipo<>'D')))opof left outer join  
					(select oa.ID, oa.NROOFERTA, adj.COMITENTE, adj.CUIT, adj.CANTIDAD cantidad_adjudicada, 
					oa.operador, oa.fch_ingreso,adj.usu_baja 
					from ORDENADJUDICACION oa, ADJUDICACION adj 
					where oa.ID = adj.nro_orden_adjudicacion and adj.USU_BAJA is null
					) adjo 
				on (adjo.usu_baja is null 
					and adjo.nrooferta = opof.numero_oferta 
					and (
						adjo.operador is null 
						or opof.operador = adjo.operador 
						and trunc(opof.hora_oferta)= trunc (adjo.fch_ingreso)
						)
					and opof.estado <>'B'
				)