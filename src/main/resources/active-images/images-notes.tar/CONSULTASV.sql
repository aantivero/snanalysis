

select FECHA_ULT_EVENTO from rueda where id=(select max(id) from RUEDA) order by id desc;
select HORAPROCESO from mensaje where id = 1 order by id;

select * from rueda order by id desc;


select * from aplicacion;

select * from operacion;

select * from OPERACION_TEMPORAL;

select * from ADJUDICACION_MOV;
select * from  ADJUDICACION;
select * from ORDENADJUDICACION;
select * from ORDEN_OFERTA;

select * from OFERTA;
select * from mensaje order by id;
select * from OFERTA_RUE_CONT;
select * from EVENTO_TP8;
select * from EVENTO;

select * from ORDEN;
select * from EVENTODEOR;
select * from BDEO_ORDEN_BOLSAR;
select * from BDEO_audit_event;
select * from POINTCAST;
select * from SOLICITUD_LIBRO_ORDENES;

select * from DEOR_APLICACION;


select * from TP8_RESPONSE order by REQUEST_DATE desc;

--RUEDA
select id,fch_rue,estado,fch_modif,fch_susp,ult_evento_proc,
consumidor_eventos_id,ult_evento_proc_sinac, estado_proc_ev 
from rueda where id in (select max(id) from rueda);

-----------FINAL
select count(*) from agente;

select * from agente;

select * from agente_backup where FCHALTA like '%25/08/2016%' order by FCHALTA desc;

select count(*) from agente_backup;
drop table agente_backup;
create table AGENTE_BACKUP AS (SELECT * FROM AGENTE); 
delete from agente;




select count(*) from comitente;
drop table comitente_backup;
create table comitente_backup as (select * from comitente);
select count(*) from comitente_backup;
delete from comitente;


select count(*) from (
  select numero, agente, estado from comitente 
  minus 
  select numero,agente, estado from COMITENTE_BACKUP);
  
select * from agente_backup minus select * from agente; 
  
select * from comitente;

select * from instrumento where tipo = 'M';

select * from formaoperativa;

select count(*) from oferta;
select count(*) from operacion;

select * from ORDEN_OFERTA order by fechaoferta desc;