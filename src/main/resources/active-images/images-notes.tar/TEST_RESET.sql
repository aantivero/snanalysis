update RUEDA
SET ULT_EVENTO_PROC = 0,
CONSUMIDOR_EVENTOS_ID = null,
ESTADO='A'
where id=(select max(id) from RUEDA);

update APLICACION
set ESTADO='A';

delete from OPERACION;
delete from OPERACION_TEMPORAL;
delete from ADJUDICACION_MOV;
delete from ADJUDICACION;
delete from ORDENADJUDICACION;
delete from ORDEN_OFERTA;

delete from OFERTA;

delete from OFERTA_RUE_CONT;
delete from EVENTO_TP8;
delete from EVENTO;
delete from MENSAJE;
delete from ORDEN;
delete from EVENTODEOR;
delete from BDEO_ORDEN_BOLSAR;
delete from BDEO_audit_event;
delete from POINTCAST;
delete from SOLICITUD_LIBRO_ORDENES;

update DEOR_APLICACION
set RUEDA_FECHA= (select FCH_RUE from RUEDA where id=(select max(id) from RUEDA));

update TP8_RESPONSE
set USED=0,DELAY_MILLIS=300;

commit;