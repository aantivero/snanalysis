select FECHA_ULT_EVENTO from rueda where id=(select max(id) from RUEDA) order by id desc;
select HORAPROCESO from mensaje where id = 43510 order by id;

--extraer los mensajes en formato de envio para la cola de mensajes
select MENSAJE || ';' ||  TIPO_TRANSACCION || ';' ||  ID
from mensaje
where NROPRIMEREVENTO is not null
order by ID;